#include "colleague/i_motion_colleague.hpp"
/*
IMotionColleague::IMotionColleague(std::shared_ptr<IMotionMediator> motion_mediator) : m_i_motion_mediator(motion_mediator){   
    
}
*/